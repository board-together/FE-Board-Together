v.1.0 - 06/01/2011

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 \\\"INCEPTION" Truetype Font \\\  Copyright 2011 by RETICULA - Vincent Wicky
  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

  ____________________________________________________________________________________

++The personnal and/or non-commercial uses of this font are FREE. 
  However donations are accepted and appreciated : www.reticula.net ! 
  Thank you for also sending me your creations ;)

++The professional and/or commercial uses of this font are PROHIBITED unless the fee 
  of the commercial licence. (see below how to contact me for details).

++You are not allowed to distribute these fonts, whatever the media (web, cd, zip, ...) 
  without my express permission. Contact me for details.

++You may never ever sell my fonts, include them on CD's or make any changes to the files.

E-mail: contact@reticula.net
WWW: http://www.reticula.net


  ___________________________________________________________________________________
  E-mail: contact@reticula.net                           WWW: http://www.reticula.net



v.1.0 - 06/01/2011

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 \\\"INCEPTION" Truetype Font \\\  Copyright 2011 by RETICULA - Vincent Wicky
  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

  ____________________________________________________________________________________

++L'usage de cette police est GRATUIT pour une utilisation personnelle et/ou non-commerciale. 
  Toutefois j'acccepte volontiers les dons : www.reticula.fr ! 
  Merci de bien vouloir �galement m'envoyer vos cr�ations ;)

++L'usage de cette police est INTERDIT pour une utilisation professionnel et/ou commercial 
  sans vous acquitter de la licence commerciale. (voir ci-dessous comment me contacter pour les d�tails).

++Vous n'�tes pas autoris� � distribuer cette police, quelque soit la forme (web, cd, zip, ...) 
  sans ma permission expresse. Contactez-moi pour les d�tails.

++Interdiction absolue de modifier, revendre ou inclure la police sur un CD.

  ___________________________________________________________________________________
  E-mail: contact@reticula.fr                           WWW: http://www.reticula.fr  




//All trademarks are property of their respective owners.//